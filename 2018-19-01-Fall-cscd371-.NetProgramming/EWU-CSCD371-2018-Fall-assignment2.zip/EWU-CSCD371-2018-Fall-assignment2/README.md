#Eastern Washington University
## CSCD 371 - Fall, 2018
with
### Mark Michelis, Kevin Bost, and Michael Stokesbary

# Checkout the [Wiki](https://github.com/IntelliTect-Samples/EWU-CSCD371-2018-Fall/wiki) for More Information

