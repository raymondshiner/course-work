﻿namespace SampleAssignment8
{
    public enum Status
    {
        Running,
        NotRunning
    }
}