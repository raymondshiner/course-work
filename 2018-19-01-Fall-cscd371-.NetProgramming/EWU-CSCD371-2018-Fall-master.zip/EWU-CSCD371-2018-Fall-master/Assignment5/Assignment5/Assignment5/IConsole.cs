﻿namespace Assignment5
{
    public interface IConsole
    {
        string ReadLine();
        void WriteLine(string line);
    }
}