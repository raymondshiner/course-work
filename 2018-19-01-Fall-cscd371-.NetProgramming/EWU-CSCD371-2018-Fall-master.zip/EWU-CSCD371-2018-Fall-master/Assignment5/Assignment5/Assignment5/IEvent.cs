﻿namespace Assignment5
{
    public interface IEvent
    {
        string Name { get; }
        string Location { get; }
    }
}