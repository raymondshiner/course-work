﻿using System;

namespace Delegates
{
    public class AddEventArgs : EventArgs
    {
        public int Value { get; set; }
    }
}