#Eastern Washington University
## CSCD 371 - Fall, 2018

### Instructors [Mark Michelis](https://github.com/MarkMichaelis), [Kevin Bost](https://github.com/Keboo), and [Michael Stokesbary](https://github.com/breaman)

# Checkout the [Wiki](https://github.com/IntelliTect-Samples/EWU-CSCD371-2018-Fall/wiki) for More Information

