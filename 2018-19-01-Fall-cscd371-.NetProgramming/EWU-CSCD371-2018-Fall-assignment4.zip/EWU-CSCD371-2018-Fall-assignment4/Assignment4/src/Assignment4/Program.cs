﻿using System;

namespace Assignment4
{
    public class Program
    {
        public static void Main(string[] args)
        {

        }
    }
}