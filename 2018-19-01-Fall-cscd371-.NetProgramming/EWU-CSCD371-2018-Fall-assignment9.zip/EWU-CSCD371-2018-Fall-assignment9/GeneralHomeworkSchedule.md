The following is a general outline of the homework each week.
* We will be using Essential C# 7.0 by Mark Michaelis as the text for the class
* Weeks start on Thursday.
* A chapter is covered each week and should be read in advance of when it is presented.  During the first week you will want to have read the first **two** chapter of the book.
* Homework is due by Midnight the following Thursday.
* Submit a pull request (PR) back to the forked (EWU-CSCD371-2018-Fall]) repo. Note: Homework is not submitted until you PR your work. Consider navigating to the original repo and checking that your PR is listed (see https://github.com/IntelliTect-Samples/EWU-CSCD371-2018-Fall/pulls).
* Late homework is NOT accepted.