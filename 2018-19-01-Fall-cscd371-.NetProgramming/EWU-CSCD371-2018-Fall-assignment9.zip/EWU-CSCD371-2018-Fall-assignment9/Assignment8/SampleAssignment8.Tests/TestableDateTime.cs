﻿using System;

namespace SampleAssignment8.Tests
{
    public class TestableDateTime : IDateTime
    {
        public DateTime Now { get; set; }
    }
}