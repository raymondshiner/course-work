﻿using System;

namespace SampleAssignment8
{
    public class RealDateTime : IDateTime
    {
        public DateTime Now => DateTime.Now;
    }
}