﻿using System;

namespace SampleAssignment8
{
    public interface IDateTime
    {
        DateTime Now { get; }
    }
}