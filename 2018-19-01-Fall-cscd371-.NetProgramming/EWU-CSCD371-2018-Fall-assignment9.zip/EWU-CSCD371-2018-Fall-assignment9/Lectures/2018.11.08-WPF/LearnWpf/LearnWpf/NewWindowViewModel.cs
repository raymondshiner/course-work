﻿using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace LearnWpf
{
    public class NewWindowViewModel : INotifyPropertyChanged
    {
        private string _Name;
        public string Name
        {
            get => _Name;
            set
            {
                if (_Name != value)
                {
                    _Name = value;
                    OnPropertyChanged();
                }
            }
        }

        public NewWindowViewModel()
        {
            Name = "Kevin";
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}