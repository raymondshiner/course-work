﻿namespace Interfaces
{
    public interface IMyConsole
    {
        void WriteLine(string line);

        object GetHost();
    }
}