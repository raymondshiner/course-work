﻿using System;

namespace Assignment8
{
    public interface IDateTime
    {
        DateTime Now();
    }
}