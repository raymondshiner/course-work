﻿namespace SecretSanta.Domain.Tests.Services
{
    public class GroupServiceTests : DatabaseServiceTests
    {
        
    }
}