﻿namespace SecretSanta.Domain.Tests.Services
{
    public class UserServiceTests : DatabaseServiceTests
    {
        
    }
}