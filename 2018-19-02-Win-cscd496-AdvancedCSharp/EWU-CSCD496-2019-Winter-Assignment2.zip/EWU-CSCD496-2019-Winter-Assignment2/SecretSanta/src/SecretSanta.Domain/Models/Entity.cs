﻿using SecretSanta.Domain.Interface;

namespace SecretSanta.Domain.Models
{
    public class Entity : IEntity
    {
        public int Id { get; set; }
    }
}