﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SecretSanta.Domain.Interface
{
    public interface IEntity
    {
        int Id { get; set; }
    }
}
