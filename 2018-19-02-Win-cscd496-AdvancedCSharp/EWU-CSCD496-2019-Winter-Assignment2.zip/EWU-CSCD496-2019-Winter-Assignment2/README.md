# EWU-CSCD496-2019-Winter

[![Join the chat at https://gitter.im/IntelliTect/CSCD496-2019-Winter](https://badges.gitter.im/IntelliTect/CSCD496-2019-Winter.svg)](https://gitter.im/IntelliTect/CSCD496-2019-Winter?utm_source=badge&utm_medium=badge&utm_campaign=pr-badge&utm_content=badge)


Updated for assignment 1
