﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SecretSanta.Api.Tests.Controllers
{
    class GroupUserControllerTests
    {
    }
}
