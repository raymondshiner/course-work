#include "genericArray.h"

GenericArray * fillArray(FILE * in, int length, void * (*buildType)(FILE * input))
{
	GenericArray * myArray = (GenericArray*)calloc(length, sizeof(GenericArray));

	int x;

	for(x = 0; x<length; x++)
	{
		myArray[x].data = buildType(in);
	}
	
	return myArray;
}


void printArray(GenericArray * array, int length, void (*printType)(void *))
{
	int x;
	printf("\n");
	for(x = 0; x < length; x++)
		printType(array[x].data);
	
	printf("\n");
}


void cleanArray(GenericArray * array, int length, void (*cleanType)(void *))
{
	int x;
	for(x = 0; x < length; x++)
		cleanType(array[x].data);
	
	free(array);
	array = NULL;

}

void sortArray(GenericArray * array, int length, int (*compar)(const void * v1, const void * v2))
{
	int start;
	int smallest;
	int cur;
	void * temp;
	
	for(start = 0; start<length-1; start++)
	{
		smallest = start;
		for(cur = start; cur<length; cur++)
		{
			if(compar(array[cur].data, array[smallest].data) < 0)
				smallest = cur;
		}
		temp = array[smallest].data;
		array[smallest].data = array[start].data;
		array[start].data = temp;
	}
}


