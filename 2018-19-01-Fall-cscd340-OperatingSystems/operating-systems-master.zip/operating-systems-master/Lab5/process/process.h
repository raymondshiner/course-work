#ifndef PROCESS_H
#define PROCESS_H

#include <string.h>
#include <stdio.h>
#include <stdlib.h>

#include <unistd.h>

void forkIt(char ** argv);

void waitpid(pid_t pid, int * status, int options);
int fork();

#endif
