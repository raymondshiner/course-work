#include "tokenize.h"

void clean(int argc, char **argv)
{
    int x = 0;
    for(x = 0; x<argc; x++)
    {
        free(argv[x]);
        argv[x] = NULL;
    }

    free(argv);
    argv = NULL;

}// end clean

void printargs(int argc, char **argv)
{
	int x;
	for(x = 0; x < argc; x++)
		printf("%s\n", argv[x]);

}// end printargs

int makeargs(char *s, char *** argv)
{
    int count = 0;
    char * cpy = (char*)calloc(strlen(s)+1, sizeof(char));

    strcpy(cpy, s);

    char * save;
    char * temp = strtok_r(cpy, " ", &save);

    while(temp != NULL) //incrementing count to right number
    {
        count ++;
        temp = strtok_r(NULL, " ", &save);
    }

    save = NULL; //reseting variables so tokenization will work
    strcpy(cpy, s);
    temp = strtok_r(cpy, " ", &save);

    (*argv)=(char**)calloc(count+1, sizeof(char*)); //initialize array

    int x = 0;

    while(temp != NULL) //fill array
    {
        (*argv)[x] = (char*)calloc(strlen(temp)+1, sizeof(char));
        strcpy((*argv)[x], temp);
        temp = strtok_r(NULL, " ", &save);
        x++;
    }

    (*argv)[x] = '\0';

    free(cpy);

    return count;

}// end makeArgs
