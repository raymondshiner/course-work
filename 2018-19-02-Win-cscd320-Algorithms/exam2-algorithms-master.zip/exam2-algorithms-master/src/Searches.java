import java.util.LinkedList;

public class Searches {
    public static void BFS(GraphMatrix G, int start) //DONE
    {
        LinkedList<Integer> q = new LinkedList<>();
        q.addLast(start);
        G.setMark(start, 1);

        while(!q.isEmpty())
        {
            int v = q.removeFirst().intValue();
            System.out.print(v + " ");
            for(Edge e = G.first(v); G.isEdge(e); e = G.next(e))
            {
                if(G.getMark(G.v2(e)) == 0)
                {
                    G.setMark(G.v2(e), 1);
                    q.addLast(G.v2(e));
                }
            }
        }
    }

    public static void DFS(GraphMatrix G, int v)
    {
        System.out.print(v + " ");
        G.setMark(v, 1);
        for(Edge e = G.first(v); G.isEdge(e); e = G.next(e))
        {
            if(G.getMark(G.v2(e)) == 0)
                DFS(G, G.v2(e));
        }
    }
}
