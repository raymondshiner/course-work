import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedList;

public class KruskalsAlgo {

    private HashSet<Edge> mst = new HashSet<>();

    public KruskalsAlgo(GraphList G)
    {
        ArrayList<Edge> edges = G.getEdges();
        edges.sort(new EdgeComparator());
        UnionFind uf = new UnionFind(G.numVertices());

        for(Edge e : edges)
        {
            if(!uf.find(e.v1(), e.v2()))
            {
                mst.add(e);
                uf.unite(e.v1(), e.v2());
            }
        }
    }

    public void print()
    {
        System.out.println("BELOW IS MST - KA");
        for(Edge e : mst)
        {
            System.out.println(e);
        }
    }
}
