public class Edge {

    private int v1;
    private int v2;
    private int weight;

    public Edge (int v1, int v2)
    {
        this.v1 = v1;
        this.v2 = v2;
        weight = 1;
    }

    public Edge (int v1, int v2, int wt)
    {
        assert (wt != 0) : "Weight cannot be 0";
        this.v1 = v1;
        this.v2 = v2;
        weight = wt;
    }

    public int v1()
    {
        return this.v1;
    }

    public int v2()
    {
        return this.v2;
    }

    public int weight() { return this.weight; }

    @Override
    public String toString()
    {
        return v1 + "-" + v2 + " - " + weight;
    }
}
