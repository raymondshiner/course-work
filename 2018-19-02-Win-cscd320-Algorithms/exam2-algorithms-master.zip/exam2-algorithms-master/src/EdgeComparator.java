import java.util.Comparator;

public class EdgeComparator implements Comparator {
    @Override
    public int compare(Object o1, Object o2) {
        if(!(o1 instanceof Edge) || !(o2 instanceof Edge))
            throw new IllegalArgumentException("Both objects in comparator must be Edges");

        Edge e1 = (Edge)o1;
        Edge e2 = (Edge)o2;

        if(e1.weight() > e2.weight())
            return 1;
        if(e2.weight() > e1.weight())
            return -1;
        return 0;
    }
}
