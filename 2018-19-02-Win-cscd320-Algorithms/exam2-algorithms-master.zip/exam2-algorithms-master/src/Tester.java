import java.util.LinkedList;

public class Tester {
    public static void main(String [] args)
    {
        GraphMatrix graphMatrix = new GraphMatrix(6);

        graphMatrix.addEdge(0,2);//A-C
        graphMatrix.addEdge(0,4);//A-E
        graphMatrix.addEdge(1,2);//B-C
        graphMatrix.addEdge(1,5);//B-F
        graphMatrix.addEdge(2,5);//C-F
        graphMatrix.addEdge(2,3);//C-D
        graphMatrix.addEdge(3,5);//D-F
        graphMatrix.addEdge(4,5);//E-F

        Searches.BFS(graphMatrix,0);
        System.out.print ("- BFS");

        graphMatrix.resetMarks();
        System.out.println();

        Searches.DFS(graphMatrix, 0);
        System.out.print ("- DFS");

        graphMatrix.resetMarks();
        System.out.println();

        GraphList graphList = new GraphList(8);
        graphList.addEdge(0, 1, 4);
        graphList.addEdge(1,7,24);
        graphList.addEdge(0,2, 6);
        graphList.addEdge(0,3,16);
        graphList.addEdge(2,3,8);
        graphList.addEdge(2,5,5);
        graphList.addEdge(7,6,9);
        graphList.addEdge(7,5,18);
        graphList.addEdge(7,2,23);
        graphList.addEdge(3,5,10);
        graphList.addEdge(3,4,21);
        graphList.addEdge(5,4,14);
        graphList.addEdge(5,6,11);
        graphList.addEdge(6,4,7);

        KruskalsAlgo KA = new KruskalsAlgo(graphList);
        KA.print();
    }
}
