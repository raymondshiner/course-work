public class GraphMatrix {

    private int [][] matrix;
    private int numEdges;
    private int [] mark;

    public GraphMatrix(int v)
    {
        if(v <= 1)
            throw new IllegalArgumentException("graph can't have less then one node");

        matrix = new int [v][v];
        mark = new int [v];
        numEdges = 0;
    }

    public boolean isEdge(Edge e)
    {
        if(e == null)
            return false;

        return matrix[e.v1()][e.v2()] != 0;
    }

    public void addEdge(int v1, int v2, int wt)
    {
        assert (wt != 0) : "Weight cannot be set to zero";

        if(matrix[v1][v2] == 0)
        {
            matrix[v1][v2] = wt;
            matrix[v2][v1] = wt;
            numEdges++;
        }
    }

    public void addEdge(int v1, int v2)
    {
        if(matrix[v1][v2] == 0)
        {
            matrix[v1][v2] = 1;
            matrix[v2][v1] = 1;
            numEdges++;
        }
    }

    public void removeEdge(Edge e)
    {
        assert (e != null) : "cannot remove edge";

        if(matrix[e.v1()][e.v2()] != 0)
        {
            matrix[e.v1()][e.v2()] = 0;
            matrix[e.v2()][e.v1()] = 0;
            numEdges--;
        }
    }

    public Edge first(int v)
    {
        for (int x=0; x<mark.length; x++) {
            if (matrix[v][x] != 0)
                return new Edge(v, x);
        }

        return null;
    }

    public Edge next(Edge e)
    {
        if(e == null)
            return null;

        for (int y = e.v2() + 1; y < mark.length; y++) {
            if (matrix[e.v1()][y] != 0)
                return new Edge(e.v1(), y);
        }

        return null;
    }

    public void setMark(int v, int value)
    {
        mark[v] = value;
    }

    public int getMark(int v) {
        return mark[v];
    }

    public void print(){

        for(int x =0; x < mark.length; x++)
        {
            for(int y = 0; y < mark.length; y++)
            {
                if(matrix[x][y] != 0)
                    System.out.println(x + " - " + y);
            }
        }
    }

    public int numEdges()
    {
        return numEdges;
    }

    public int v1(Edge e)
    {
        return e.v1();
    }

    public int v2(Edge e)
    {
        return e.v2();
    }

    public void resetMarks()
    {
        for(int x= 0; x < mark.length; x++)
            mark[x] = 0;
    }

    public int numVertices()
    {
        return mark.length;
    }

}
