import java.util.ArrayList;
import java.util.HashSet;

public class UnionFind {
    private ArrayList<HashSet<Integer>> componenets;

    public UnionFind(int v)
    {
        assert (v > 0) : "Cannot have union find with less than 1 vertex";

        componenets = new ArrayList<>();

        for(int x = 0; x < v; x++)
        {
            HashSet<Integer> set = new HashSet<>();
            set.add(x);
            componenets.add(set);
        }
    }

    public boolean find(int v1, int v2)
    {
        boolean found = false;
        for(int x = 0; x<componenets.size(); x++)
        {
            HashSet set = componenets.get(x);
            if(set.contains(v1) && set.contains(v2))
                found = true;
        }
        return found;
    }

    public boolean unite(int v1, int v2)
    {
        HashSet<Integer> newSet = new HashSet<>();
        HashSet<Integer> setA = null, setB = null;

        for(int x =0; x<componenets.size(); x++)
        {
            HashSet set = componenets.get(x);
            if(set.contains(v1))
                setA = set;
            if(set.contains(v2))
                setB = set;
        }

        if(setA == null || setB == null)
            return false;

        newSet.addAll(setA);
        newSet.addAll(setB);

        componenets.remove(setA);
        componenets.remove(setB);

        componenets.add(newSet);

        return true;
    }


}
