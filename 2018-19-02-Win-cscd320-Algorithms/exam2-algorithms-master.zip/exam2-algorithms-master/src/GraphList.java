import java.util.ArrayList;
import java.util.LinkedList;

public class GraphList {

    private int numVertices;
    private ArrayList<Edge> edges;
    private LinkedList<Edge>[] adjList;

    public GraphList(int v) {
        numVertices = v;
        edges = new ArrayList<>();
        adjList = new LinkedList[v];

        for (int x = 0; x < v; x++) {
            adjList[x] = new LinkedList();
        }
    }

    public void addEdge(int v1, int v2, int weight) {

        Edge e = new Edge(v1, v2, weight);
        addEdge(e);
    }

    public void addEdge(Edge e)
    {
        adjList[e.v1()].add(e);
        adjList[e.v2()].add(e);
        edges.add(e);
    }

    public void removeEdge(int v1, int v2)
    {
        Edge e = new Edge(v1, v2);
        removeEdge(e);
    }

    public void removeEdge(Edge e)
    {
        adjList[e.v1()].remove(e);
        adjList[e.v2()].remove(e);
        edges.remove(e);
    }

    public LinkedList<Edge> adj(int v)
    {
        return adjList[v];
    }

    public ArrayList<Edge> getEdges()
    {
        return edges;
    }

    public int numVertices()
    {
        return numVertices;
    }

}
